AIM/LOCAL V2 1.0.0 — preuves visuelles natives
Ouvrir gallery.html. Toutes les captures proviennent de scenes/app/MainV2.tscn.
Le profil QA est isolé. Les pratiques sont des snapshots du moteur sans entrée joueur.
Les huit décisions CAL viennent de fixtures synthétiques identifiées dans le manifeste et les images.
Projection analytique contre Camera3D : erreur maximale 0,5 px. Corps de cible : sRGB #42D9CB exact.
Ce contrôle ne mesure pas les FPS matériels, la latence physique ni la réception Windows.
